Model MIP to Switch Allocation
